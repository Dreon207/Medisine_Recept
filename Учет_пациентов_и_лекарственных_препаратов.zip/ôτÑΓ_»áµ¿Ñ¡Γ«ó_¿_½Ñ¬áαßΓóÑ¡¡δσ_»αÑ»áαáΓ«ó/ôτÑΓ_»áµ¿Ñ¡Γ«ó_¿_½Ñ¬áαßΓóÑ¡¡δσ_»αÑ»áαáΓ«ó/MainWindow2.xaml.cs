﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Учет_пациентов_и_лекарственных_препаратов.Patients_and_MedicinesDataSetTableAdapters;

namespace Учет_пациентов_и_лекарственных_препаратов
{
    /// <summary>
    /// Логика взаимодействия для MainWindow2.xaml
    /// </summary>
    public partial class MainWindow2 : Page
    {
        UsersTableAdapter user = new UsersTableAdapter();
        public MainWindow2()
        {
            InitializeComponent();
            GridUs.ItemsSource = user.GetData();
        }

        private void Registration(object sender, RoutedEventArgs e)
        {
            Framu.Content = new Registration();
        }

        private void Open(object sender, RoutedEventArgs e)
        {
            List<string> role = new List<string>();
            List<string> people = new List<string>();
            List<string> pass = new List<string>();
            string pcass = Pass.Password;
            int i = 0;
            int q = 0;
            int count_row = GridUs.Items.Count - 1;
            while (i != count_row)
            {
                GridUs.SelectedItem = GridUs.Items[i];
                GridUs.ScrollIntoView(GridUs.Items[i]);
                object cell = (GridUs.SelectedItem as DataRowView).Row[2];
                people.Add(cell.ToString());
                GridUs.SelectedItem = GridUs.Items[i];
                GridUs.ScrollIntoView(GridUs.Items[i]);
                object cell2 = (GridUs.SelectedItem as DataRowView).Row[3];
                pass.Add(cell2.ToString());
                GridUs.SelectedItem = GridUs.Items[i];
                GridUs.ScrollIntoView(GridUs.Items[i]);
                object cell3 = (GridUs.SelectedItem as DataRowView).Row[1];
                role.Add(cell3.ToString());
                i++;
            }
            while (q != count_row)
            {
                string Person = people[q];
                string Pass = pass[q];
                string Role = role[q];
                if (Login.Text == Person && pcass == Pass)
                {
                    if (Role == "1")
                    {
                        Framu.Content = new MenuAdmin();
                        break;
                    }
                    else
                    {
                        Framu.Content = new MenuUser();
                        break;
                    }
                }
                else
                {
                    q++;
                }
            }
            //string login = Login.Text;
            //DataGridColumn cell = GridUs
            //Framu.Content = new MenuAdmin();//Авторизация через БД
        }
    }
}
