﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Учет_пациентов_и_лекарственных_препаратов.Patients_and_MedicinesDataSetTableAdapters;

namespace Учет_пациентов_и_лекарственных_препаратов
{
    /// <summary>
    /// Логика взаимодействия для Registration.xaml
    /// </summary>
    public partial class Registration : Page
    {
        UsersTableAdapter user = new UsersTableAdapter();
        public Registration()
        {
            InitializeComponent();
            Gridus.ItemsSource = user.GetData();
            Login.MaxLength = 10;
            Name.MaxLength = 15;
            Pass.MaxLength = 16;
            PassPov.MaxLength = 16;
        }

        private void Back(object sender, RoutedEventArgs e)
        {
            Framu.Content = new MainWindow2();

        }

        private void Registr(object sender, RoutedEventArgs e)
        {
            if (Pass.Password == PassPov.Password) {
                user.AddMed(2, Login.Text, Pass.Password, Name.Text);
                Gridus.ItemsSource = user.GetData();
                MessageBox.Show("Регистрация прошла успешно!");
                Framu.Content = new MainWindow2();
            }
            else
            {
                MessageBox.Show("Пароли не совпадают");
            }
        }
    }
}
