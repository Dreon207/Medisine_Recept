﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Учет_пациентов_и_лекарственных_препаратов.Patients_and_MedicinesDataSetTableAdapters;

namespace Учет_пациентов_и_лекарственных_препаратов
{
    /// <summary>
    /// Логика взаимодействия для Medisines.xaml
    /// </summary>
    public partial class Medisines : UserControl
    {
        MedicinesTableAdapter table = new MedicinesTableAdapter();
        public Medisines()
        {
            DateTime date = new DateTime(1999, 10, 10);
            Console.WriteLine(date.AddDays(20));    //спустя 20 дней
            Console.ReadLine();
            InitializeComponent();
            Gridus.ItemsSource = table.GetData();
            Name.MaxLength = 20;
            Opis.MaxLength = 100;
            NoSov.MaxLength = 30;
            Simpt.MaxLength = 100;
            Doza.MaxLength = 15;
            List<DateTime> data = new List<DateTime>();
            List<Int32> plus = new List<Int32>();
            int i = 0;
            int q = 0;
            int count_row = Gridus.Items.Count - 1;
            while (i != count_row)
            {
                Gridus.SelectedItem = Gridus.Items[i];
                Gridus.ScrollIntoView(Gridus.Items[i]);
                object cell = (Gridus.SelectedItem as DataRowView).Row[4];
                var dateTime = DateTime.Parse(cell.ToString());
                data.Add(dateTime);
                Gridus.SelectedItem = Gridus.Items[i];
                Gridus.ScrollIntoView(Gridus.Items[i]);
                object cell2 = (Gridus.SelectedItem as DataRowView).Row[3];
                int parsu = (int)cell2;
                plus.Add(parsu);
                i++;
            }
            while (q != count_row)
            {
                DateTime Istok = data[q];
                int plusa = plus[q];
                Istok.AddDays(plusa);
                DateTime curDate = DateTime.Now;
                if (curDate < Istok)
                {
                    System.Windows.MessageBox.Show("Обноруженно просроченное лекарство");

                }
                else
                {
                    q++;
                }


            }

        }

        private void Back(object sender, RoutedEventArgs e)
        {
            Framu.Content = new MenuUser();
        }

        private void Delite(object sender, RoutedEventArgs e)
        {

            object id = (Gridus.SelectedItem as DataRowView).Row[0];
            table.DeleteMed(Convert.ToInt32(id));
            System.Windows.MessageBox.Show("Произведено удаление лекарства");
            Gridus.ItemsSource = table.GetData();
        }

        private void Rework(object sender, RoutedEventArgs e)
        {

            string Kodu = Kod.Text;
            int KoduInt = Convert.ToInt32(Kodu);
            string Godenu = Goden.Text;
            int GodenuInt = Convert.ToInt32(Godenu);
            string Dat = Data.Text;
            var cultureInfo = new CultureInfo("ru-RU");
            var dateTime = DateTime.Parse(Dat, cultureInfo);
            object id = (Gridus.SelectedItem as DataRowView).Row[0];
            table.UpdateMed(Name.Text, Opis.Text, GodenuInt, Data.Text, Simpt.Text, Doza.Text, KoduInt, NoSov.Text, Convert.ToInt32(id));
            System.Windows.MessageBox.Show("Произведено изменения лекарства");
            Gridus.ItemsSource = table.GetData();
        }

        private void Add(object sender, RoutedEventArgs e)
        {

            string Kodu = Kod.Text;
            int KoduInt = Convert.ToInt32(Kodu);
            string Godenu = Goden.Text;
            int GodenuInt = Convert.ToInt32(Godenu);
            string Dat = Data.Text;
            var cultureInfo = new CultureInfo("ru-RU");
            var dateTime = DateTime.Parse(Dat, cultureInfo);
            table.AddMed(Name.Text, Opis.Text, GodenuInt, Data.Text, Simpt.Text, Doza.Text, KoduInt, NoSov.Text);
            System.Windows.MessageBox.Show("Произведено добавление лекарства");
            Gridus.ItemsSource = table.GetData();
        }
    }
}
