﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Учет_пациентов_и_лекарственных_препаратов
{
    /// <summary>
    /// Логика взаимодействия для MenuAdmin.xaml
    /// </summary>
    public partial class MenuAdmin : Page
    {
        public MenuAdmin()
        {
            InitializeComponent();
        }

        private void Medicines(object sender, RoutedEventArgs e)
        {
            Framu.Content = new Medicines();
        }

        private void Recipes(object sender, RoutedEventArgs e)
        {
            Framu.Content = new Recipes();
        }

        private void Back(object sender, RoutedEventArgs e)
        {
            Framu.Content = new MainWindow2();
        }
        private void Role(object sender, RoutedEventArgs e)
        {
            Framu.Content = new Role();
        }
        private void User(object sender, RoutedEventArgs e)
        {
            Framu.Content = new User();
        }


    }
}
