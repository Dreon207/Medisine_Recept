﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Учет_пациентов_и_лекарственных_препаратов.Patients_and_MedicinesDataSetTableAdapters;

namespace Учет_пациентов_и_лекарственных_препаратов
{
    /// <summary>
    /// Логика взаимодействия для Recipes.xaml
    /// </summary>
    public partial class Recipes : Page
    {
        RecipesTableAdapter table = new RecipesTableAdapter();
        public Recipes()
        {
            InitializeComponent();
            Gridus.ItemsSource = table.GetData();
            Name.MaxLength = 15;
            LastName.MaxLength = 15;
            Disease.MaxLength = 50;
            Descri.MaxLength = 100;
        }

        private void Back(object sender, RoutedEventArgs e)
        {
            Framu.Content = new MenuAdmin();
        }

        private void Delite(object sender, RoutedEventArgs e)
        {
            object id = (Gridus.SelectedItem as DataRowView).Row[0];
            table.DeleteMed(Convert.ToInt32(id));
            Gridus.ItemsSource = table.GetData();
        }

        private void Rework(object sender, RoutedEventArgs e)
        {
            string h = PassportInt.Text;
            int a = Convert.ToInt32(h);

            string z = One.Text;
            int y = Convert.ToInt32(z);
            string x = Two.Text;
            int u = Convert.ToInt32(x);
            string c = Three.Text;
            int i = Convert.ToInt32(c);
            string v = Four.Text;
            int o = Convert.ToInt32(v);
            string b = Five.Text;
            int p = Convert.ToInt32(b);
            string n = Six.Text;
            int l = Convert.ToInt32(n);

            string m = Farma.Text;
            int t = Convert.ToInt32(m);
            object id = (Gridus.SelectedItem as DataRowView).Row[0];
            table.UpdateMed(Name.Text, LastName.Text, a, Data.Text, Disease.Text, Descri.Text, y, u, i, o, p, l, t, Convert.ToInt32(id));
            Gridus.ItemsSource = table.GetData();
        }

        private void Add(object sender, RoutedEventArgs e)
        {
            string h = PassportInt.Text;
            int a = Convert.ToInt32(h);

            string z = One.Text;
            int y = Convert.ToInt32(z);
            string x = Two.Text;
            int u = Convert.ToInt32(x);
            string c = Three.Text;
            int i = Convert.ToInt32(c);
            string v = Four.Text;
            int o = Convert.ToInt32(v);
            string b = Five.Text;
            int p = Convert.ToInt32(b);
            string n = Six.Text;
            int l = Convert.ToInt32(n);

            string m = Farma.Text;
            int t = Convert.ToInt32(m);

            table.AddMed(Name.Text, LastName.Text, a, Data.Text, Disease.Text, Descri.Text, y, u, i, o, p, l, t);
            Gridus.ItemsSource = table.GetData();
        }
    }
}
