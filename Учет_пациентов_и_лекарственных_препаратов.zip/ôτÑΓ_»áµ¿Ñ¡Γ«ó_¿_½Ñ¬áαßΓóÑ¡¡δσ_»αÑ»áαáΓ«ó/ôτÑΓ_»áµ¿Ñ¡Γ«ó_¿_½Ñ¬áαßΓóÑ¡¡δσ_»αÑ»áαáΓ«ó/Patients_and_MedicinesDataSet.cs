﻿namespace Учет_пациентов_и_лекарственных_препаратов
{


    partial class Patients_and_MedicinesDataSet
    {
        partial class MedicinesDataTable
        {
        }
    }
}

namespace Учет_пациентов_и_лекарственных_препаратов.Patients_and_MedicinesDataSetTableAdapters {
    
    
    public partial class MedicinesTableAdapter {
    }
}
