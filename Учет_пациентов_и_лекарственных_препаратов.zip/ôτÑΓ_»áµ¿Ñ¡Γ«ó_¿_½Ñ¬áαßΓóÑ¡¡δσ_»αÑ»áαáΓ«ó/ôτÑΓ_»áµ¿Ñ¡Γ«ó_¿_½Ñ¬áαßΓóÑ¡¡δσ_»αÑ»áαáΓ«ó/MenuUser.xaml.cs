﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Учет_пациентов_и_лекарственных_препаратов
{
    /// <summary>
    /// Логика взаимодействия для MenuUser.xaml
    /// </summary>
    public partial class MenuUser : Page
    {
        public MenuUser()
        {
            InitializeComponent();
        }
        private void Medicines(object sender, RoutedEventArgs e)
        {
            Framu.Content = new Medisines();
        }

        private void Recipes(object sender, RoutedEventArgs e)
        {
            Framu.Content = new RecipecUs();
        }

        private void Back(object sender, RoutedEventArgs e)
        {
            Framu.Content = new MainWindow2();
        }
    }
}
