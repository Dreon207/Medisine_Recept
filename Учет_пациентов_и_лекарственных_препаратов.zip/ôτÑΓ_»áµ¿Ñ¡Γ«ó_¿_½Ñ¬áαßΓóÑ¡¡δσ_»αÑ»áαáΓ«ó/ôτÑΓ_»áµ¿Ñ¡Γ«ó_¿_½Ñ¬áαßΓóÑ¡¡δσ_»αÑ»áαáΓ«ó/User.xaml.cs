﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Учет_пациентов_и_лекарственных_препаратов.Patients_and_MedicinesDataSetTableAdapters;

namespace Учет_пациентов_и_лекарственных_препаратов
{
    /// <summary>
    /// Логика взаимодействия для User.xaml
    /// </summary>
    public partial class User : Page
    {
        UsersTableAdapter table = new UsersTableAdapter();
        public User()
        {
            InitializeComponent();
            Gridus.ItemsSource = table.GetData();
            Login.MaxLength = 10;
            Name.MaxLength = 15;
            Pass.MaxLength = 16;
        }


        private void Back(object sender, RoutedEventArgs e)
        {
            Framu.Content = new MenuAdmin();
        }

        private void Delite(object sender, RoutedEventArgs e)
        {

            object id = (Gridus.SelectedItem as DataRowView).Row[0];
            table.DeleteMed(Convert.ToInt32(id));
            Gridus.ItemsSource = table.GetData();
        }

        private void Rework(object sender, RoutedEventArgs e)
        {
            string h = Role.Text;
            int a = Convert.ToInt32(h);
            object id = (Gridus.SelectedItem as DataRowView).Row[0];
            table.UpdateMed(a, Login.Text, Pass.Text, Name.Text, Convert.ToInt32(id));
            Gridus.ItemsSource = table.GetData();
        }

        private void Add(object sender, RoutedEventArgs e)
        {
            string h = Role.Text;
            int a = Convert.ToInt32(h);
            table.AddMed(a, Login.Text, Pass.Text, Name.Text);
            Gridus.ItemsSource = table.GetData();
        }
    }
}
